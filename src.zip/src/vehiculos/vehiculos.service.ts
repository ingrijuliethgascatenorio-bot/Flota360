import {
  Injectable,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Vehiculo } from './vehiculo.entity';
import { CreateVehiculoDto } from './dto/create-vehiculo.dto';
import { UpdateVehiculoDto } from './dto/update-vehiculo.dto';

@Injectable()
export class VehiculosService {
  constructor(
    @InjectRepository(Vehiculo)
    private readonly repo: Repository<Vehiculo>,
  ) {}

  async crear(dto: CreateVehiculoDto): Promise<Vehiculo> {
    const existe = await this.repo.findOne({
      where: { placa: dto.placa.toUpperCase() },
    });
    if (existe)
      throw new ConflictException(
        `Ya existe un vehículo con la placa ${dto.placa}`,
      );

    const vehiculo = this.repo.create({
      ...dto,
      placa: dto.placa.toUpperCase(),
    });
    return this.repo.save(vehiculo);
  }

  async listar(): Promise<Vehiculo[]> {
    return this.repo.find({
      where: { activo: true },
      order: { createdAt: 'DESC' },
    });
  }

  async buscarPorId(id: number): Promise<Vehiculo> {
    const vehiculo = await this.repo.findOne({
      where: { id },
      relations: ['documentos'],
    });
    if (!vehiculo) throw new NotFoundException(`Vehículo #${id} no encontrado`);
    return vehiculo;
  }

  async actualizar(id: number, dto: UpdateVehiculoDto): Promise<Vehiculo> {
    const vehiculo = await this.buscarPorId(id);

    if (dto.placa && dto.placa.toUpperCase() !== vehiculo.placa) {
      const existe = await this.repo.findOne({
        where: { placa: dto.placa.toUpperCase() },
      });
      if (existe)
        throw new ConflictException(`La placa ${dto.placa} ya está registrada`);
    }

    Object.assign(vehiculo, {
      ...dto,
      placa: dto.placa ? dto.placa.toUpperCase() : vehiculo.placa,
    });

    return this.repo.save(vehiculo);
  }

  async eliminar(id: number): Promise<void> {
    const vehiculo = await this.buscarPorId(id);
    vehiculo.activo = false;
    await this.repo.save(vehiculo);
  }
}
